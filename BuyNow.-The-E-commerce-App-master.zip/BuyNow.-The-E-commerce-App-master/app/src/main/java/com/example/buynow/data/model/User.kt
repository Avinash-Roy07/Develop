package com.example.buynow.data.model

data class User(
    val userName: String = "",
    val userImage:String = "",
    val userUid:String = "",
    val userEmail:String = "",
    val userAddress:String = "",
    val userPhone: String = ""
)