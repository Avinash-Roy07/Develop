package com.example.buynow.data.model

data class Category(
    val Name: String,
    val Image: String
)